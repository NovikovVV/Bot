MEXC AutoBot Web - package

Files:
- mexc_autobot_web_auth.py : bot + web UI with per-user auth
- data/ : directory where DB and encryption.key will be stored

Quick start:
1) Install dependencies:
   sudo apt update
   sudo apt install -y python3 python3-pip build-essential libssl-dev libffi-dev python3-dev
   pip install --upgrade pip
   pip install fastapi uvicorn[standard] requests tabulate cryptography

2) Run:
   uvicorn mexc_autobot_web_auth:app --host 0.0.0.0 --port 8000

3) Open browser: http://<server-ip>:8000

Notes:
- encryption key will be created automatically in data/encryption.key
- API keys are encrypted in the DB
- TEST mode simulates orders; LIVE mode attempts real orders (use with caution)
