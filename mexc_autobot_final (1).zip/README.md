MEXC AutoBot Final
==================

Unpack and run:

1) cd ~/mexc_autobot_final
2) bash install.sh
3) source venv/bin/activate
4) python -m uvicorn app.main:app --host 0.0.0.0 --port 8000

Register a user at /register (use TEST mode first). deposit_pct is percent of total deposit_usdt (common deposit for all assets).
