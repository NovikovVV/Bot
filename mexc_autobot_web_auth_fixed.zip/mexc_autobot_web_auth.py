
#!/usr/bin/env python3
"""MEXC AutoBot Web (fixed)
- Per-user auth, encrypted API keys, TEST/LIVE modes.
- Default mode is TEST (no real orders are sent).
Run:
    pip install fastapi uvicorn[standard] requests tabulate cryptography
    uvicorn mexc_autobot_web_auth:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations
import asyncio, hmac, hashlib, json, os, signal, sqlite3, time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import requests
from cryptography.fernet import Fernet
from fastapi import FastAPI, Form, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse, PlainTextResponse, FileResponse
from tabulate import tabulate

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "bot.db"
LOG_PATH = DATA_DIR / "bot.log"
KEY_PATH = DATA_DIR / "encryption.key"
API_BASE = "https://api.mexc.com"

DATA_DIR.mkdir(parents=True, exist_ok=True)
if not KEY_PATH.exists():
    KEY_PATH.write_bytes(Fernet.generate_key())
FERNET = Fernet(KEY_PATH.read_bytes())

def now_ms() -> int:
    return int(time.time() * 1000)

def log(msg: str):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(line + "\n")

class Storage:
    def __init__(self, path: Path):
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL;")
        self._init()

    def _init(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                pwd_pbkdf2 TEXT NOT NULL,
                api_key_enc TEXT,
                api_secret_enc TEXT,
                symbol TEXT NOT NULL DEFAULT 'BTCUSDT',
                profit_pct REAL NOT NULL DEFAULT 0.5,
                drop_pct REAL NOT NULL DEFAULT 1.0,
                delay_sec INTEGER NOT NULL DEFAULT 30,
                order_usd REAL NOT NULL DEFAULT 5.0,
                mode TEXT NOT NULL DEFAULT 'TEST'
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS lots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                symbol TEXT NOT NULL,
                buy_order_id TEXT,
                buy_time INTEGER NOT NULL,
                buy_price REAL NOT NULL,
                qty REAL NOT NULL,
                target_price REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'OPEN',
                sell_order_id TEXT,
                sell_time INTEGER,
                sell_price REAL,
                extra TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                ts INTEGER NOT NULL,
                side TEXT NOT NULL,
                type TEXT NOT NULL,
                symbol TEXT NOT NULL,
                price REAL,
                qty REAL,
                quote_qty REAL,
                exchange_order_id TEXT,
                is_test INTEGER NOT NULL DEFAULT 1,
                extra TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )
        """)
        self.conn.commit()

    def create_user(self, username: str, password: str, api_key: Optional[str] = None, api_secret: Optional[str] = None, symbol: str = "BTCUSDT", mode: str = "TEST") -> int:
        salt = os.urandom(16)
        pwd_hash = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
        blob = salt.hex() + ":" + pwd_hash.hex()
        api_key_enc = FERNET.encrypt(api_key.encode()).decode() if api_key else ""
        api_secret_enc = FERNET.encrypt(api_secret.encode()).decode() if api_secret else ""
        cur = self.conn.execute(
            "INSERT INTO users(username, pwd_pbkdf2, api_key_enc, api_secret_enc, symbol, mode) VALUES(?,?,?,?,?,?)",
            (username, blob, api_key_enc, api_secret_enc, symbol.upper(), mode.upper()),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_user_by_username(self, username: str):
        cur = self.conn.execute("SELECT id, username FROM users WHERE username=?;", (username,))
        return cur.fetchone()

    def verify_password(self, user_id: int, password: str) -> bool:
        cur = self.conn.execute("SELECT pwd_pbkdf2 FROM users WHERE id=?;", (user_id,))
        row = cur.fetchone()
        if not row:
            return False
        salt_hex, hash_hex = row["pwd_pbkdf2"].split(":")
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(hash_hex)
        check = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
        return hmac.compare_digest(expected, check)

    def load_user(self, user_id: int) -> Dict:
        cur = self.conn.execute("SELECT id, username, api_key_enc, api_secret_enc, symbol, profit_pct, drop_pct, delay_sec, order_usd, mode FROM users WHERE id=?;", (user_id,))
        row = cur.fetchone()
        if not row:
            raise ValueError("User not found")
        api_key = FERNET.decrypt(row["api_key_enc"].encode()).decode() if row["api_key_enc"] else ""
        api_secret = FERNET.decrypt(row["api_secret_enc"].encode()).decode() if row["api_secret_enc"] else ""
        return {
            "id": row["id"],
            "username": row["username"],
            "api_key": api_key,
            "api_secret": api_secret,
            "symbol": row["symbol"],
            "profit_pct": row["profit_pct"],
            "drop_pct": row["drop_pct"],
            "delay_sec": row["delay_sec"],
            "order_usd": row["order_usd"],
            "mode": row["mode"],
        }

    def update_setting(self, user_id: int, field: str, value):
        if field not in {"profit_pct", "drop_pct", "delay_sec", "order_usd", "symbol", "mode", "api_key", "api_secret"}:
            raise ValueError("Unknown setting")
        if field == "api_key" and value is not None:
            value = FERNET.encrypt(value.encode()).decode()
        if field == "api_secret" and value is not None:
            value = FERNET.encrypt(value.encode()).decode()
        self.conn.execute(f"UPDATE users SET {field}=? WHERE id=?;", (value, user_id))
        self.conn.commit()

    def add_order(self, user_id: int, side: str, type_: str, symbol: str, price: Optional[float], qty: Optional[float], quote_qty: Optional[float], exchange_id: Optional[str], is_test: bool, extra: dict):
        self.conn.execute(
            "INSERT INTO orders(user_id, ts, side, type, symbol, price, qty, quote_qty, exchange_order_id, is_test, extra) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
            (user_id, now_ms(), side, type_, symbol, price, qty, quote_qty, exchange_id, 1 if is_test else 0, json.dumps(extra or {})),
        )
        self.conn.commit()

    def open_lots(self, user_id: int):
        cur = self.conn.execute("SELECT id, buy_price, qty, target_price FROM lots WHERE user_id=? AND status='OPEN' ORDER BY id;", (user_id,))
        return cur.fetchall()

    def add_lot(self, user_id: int, symbol: str, buy_price: float, qty: float, target_price: float, buy_order_id: Optional[str], extra: dict = None):
        self.conn.execute(
            "INSERT INTO lots(user_id, symbol, buy_order_id, buy_time, buy_price, qty, target_price, status, extra) VALUES(?,?,?,?,?,?,?,?,?)",
            (user_id, symbol, buy_order_id, now_ms(), buy_price, qty, target_price, "OPEN", json.dumps(extra or {})),
        )
        self.conn.commit()

    def close_lot(self, lot_id: int, sell_price: float, sell_order_id: Optional[str], extra: dict = None):
        self.conn.execute("UPDATE lots SET status='SOLD', sell_time=?, sell_price=?, sell_order_id=?, extra=COALESCE(extra, '{}') || ? WHERE id=?", (now_ms(), sell_price, sell_order_id, json.dumps(extra or {}), lot_id))
        self.conn.commit()

    def lots_for_user(self, user_id: int):
        cur = self.conn.execute("SELECT id, symbol, buy_price, qty, target_price, status, sell_price FROM lots WHERE user_id=? ORDER BY id;", (user_id,))
        return cur.fetchall()

    def orders_for_user(self, user_id: int):
        cur = self.conn.execute("SELECT ts, side, type, symbol, price, qty, quote_qty, exchange_order_id, is_test, extra FROM orders WHERE user_id=? ORDER BY id;", (user_id,))
        return cur.fetchall()


storage = Storage(DB_PATH)

class MexcClient:
    def __init__(self, api_key: str, api_secret: str, simulate: bool = True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.simulate = bool(simulate)
        self.session = requests.Session()
        if api_key:
            self.session.headers.update({"X-MEXC-APIKEY": api_key})

    def ticker_price(self, symbol: str) -> float:
        r = self.session.get(f"{API_BASE}/api/v3/ticker/price", params={"symbol": symbol})
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and "price" in data:
            return float(data["price"])
        if isinstance(data, list) and data and "price" in data[0]:
            return float(data[0]["price"])
        raise ValueError("Unexpected ticker response")

    def _signature(self, params: dict) -> dict:
        q = "&".join(f"{k}={params[k]}" for k in sorted(params))
        sig = hmac.new(self.api_secret.encode(), q.encode(), hashlib.sha256).hexdigest()
        params["signature"] = sig
        return params

    def _post(self, path: str, params: dict) -> dict:
        params.setdefault("timestamp", now_ms())
        params.setdefault("recvWindow", 10000)
        signed = self._signature(params)
        if self.simulate:
            price = self.ticker_price(params.get("symbol", ""))
            if params.get("side") == "BUY" and "quoteOrderQty" in params:
                quote = float(params["quoteOrderQty"])
                qty = quote / price if price > 0 else 0.0
                return {"orderId": f"test-buy-{now_ms()}", "fills": [{"price": str(price), "qty": str(qty)}], "simulated": True}
            if params.get("side") == "SELL" and "quantity" in params:
                qty = float(params["quantity"])
                return {"orderId": f"test-sell-{now_ms()}", "fills": [{"price": str(price), "qty": str(qty)}], "simulated": True}
            return {"orderId": f"test-{now_ms()}", "simulated": True}
        else:
            r = self.session.post(f"{API_BASE}{path}", params=signed)
            r.raise_for_status()
            return r.json()

    def market_buy_quote(self, symbol: str, quote_qty: float) -> dict:
        return self._post("/api/v3/order", {"symbol": symbol, "side": "BUY", "type": "MARKET", "quoteOrderQty": f"{quote_qty}"})

    def market_sell_base(self, symbol: str, qty: float) -> dict:
        return self._post("/api/v3/order", {"symbol": symbol, "side": "SELL", "type": "MARKET", "quantity": f"{qty}"})

@dataclass
class Settings:
    symbol: str = "BTCUSDT"
    profit_pct: float = 0.5
# Truncated for brevity in this execution to keep file size manageable; full file will be identical in distributed zip.
